package Greenset;

public interface CantidadDeAgua {
    void CalcularVätska();
}
